let a = require('./b');
let aver = a.average(1,3,5,7,9,10);
console.log(aver);