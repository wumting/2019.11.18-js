let average = function(){
    let arg = Array.from(arguments);
    let argSort = arg.sort((a,b)=> a-b);
    argSort.splice(0,1);
    argSort.length--;
    let sum = require('./a');
    let total = sum.sum(...arg); 
    return total/arg.length; 
}
module.exports={
    average,
}